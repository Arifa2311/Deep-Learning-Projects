import streamlit as st
import matplotlib.pyplot as plt
from settings_app import settings_page
from settings_app import build_model, train_model, plot_decision_surface


 # Applying background color using CSS
st.markdown(
        """
        <style>
    .stApp {
        background-image: linear-gradient(to right,#5F7DAF, #E2C3C8, #AFAFC7, #F7DFD3);
    }
    h1 {
        color: #6D6895; /* Color for Tensorflow Playground Clone heading */
    }
    
    </style>
        """,
        unsafe_allow_html=True
    )


def display_page(X_train, y_train, X_test, y_test, batch_size, epochs, learning_rate, activation):
    st.title('TensorFlow Playground Clone')
    st.markdown("---")

    # Building the model
    model = build_model(activation)

    # Training the model
    history = train_model(model, X_train, y_train, X_test, y_test, batch_size, epochs, learning_rate)

    # Visualizing decision surface
    plot_decision_surface(model, X_train, y_train, X_test, y_test)

    # Plotting the training history
    st.write('**Training History**')
    fig, ax = plt.subplots()
    ax.plot(history.history['loss'], label='Train Loss')
    ax.plot(history.history['val_loss'], label='Test Loss')
    ax.set_xlabel('Epochs')
    ax.set_ylabel('Loss')
    ax.legend()
    st.pyplot(fig)

    st.write('**Train Loss:**', history.history['loss'][-1])
    st.write('**Test Loss:**', history.history['val_loss'][-1])

def main():
    # Settings Page
    settings = settings_page()

    if settings:
        X_train, y_train, X_test, y_test, batch_size, epochs, learning_rate, activation = settings
        display_page(X_train, y_train, X_test, y_test, batch_size, epochs, learning_rate, activation)
    else:
        st.write("Please provide settings and click on 'Submit'.")

if __name__ == "__main__":
    main()
