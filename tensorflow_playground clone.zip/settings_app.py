import streamlit as st
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
import tensorflow as tf
import matplotlib.pyplot as plt

def load_datasets():
    paths = [
        ("U-shape", r"C:\Users\Afrin\Downloads\Multiple CSV (1)\Multiple CSV\1.ushape.csv"),
        ("Concentric Circle 1", r"C:\Users\Afrin\Downloads\Multiple CSV (1)\Multiple CSV\2.concerticcir1.csv"),
        ("Concentric Circle 2", r"C:\Users\Afrin\Downloads\Multiple CSV (1)\Multiple CSV\3.concertriccir2.csv"),
        ("Linear Separable", r"C:\Users\Afrin\Downloads\Multiple CSV (1)\Multiple CSV\4.linearsep.csv"),
        ("Outliers", r"C:\Users\Afrin\Downloads\Multiple CSV (1)\Multiple CSV\5.outlier.csv"),
        ("Overlapping", r"C:\Users\Afrin\Downloads\Multiple CSV (1)\Multiple CSV\6.overlap.csv"),
        ("XOR", r"C:\Users\Afrin\Downloads\Multiple CSV (1)\Multiple CSV\7.xor.csv"),
        ("Two Spirals", r"C:\Users\Afrin\Downloads\Multiple CSV (1)\Multiple CSV\8.twospirals.csv")
    ]
    datasets = {}
    for name, path in paths:
        df = pd.read_csv(path, header=None)
        datasets[name] = df
    return datasets

def build_model(activation):
    model = tf.keras.Sequential([
        tf.keras.layers.Dense(64, activation=activation, input_shape=(2,)),
        tf.keras.layers.Dense(64, activation=activation),
        tf.keras.layers.Dense(1, activation='sigmoid')
    ])
    model.compile(optimizer='adam',
                  loss='binary_crossentropy',
                  metrics=['accuracy'])
    return model

def train_model(model, X_train, y_train, X_test, y_test, batch_size, epochs, learning_rate):
    history = model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, validation_data=(X_test, y_test), verbose=0)
    return history

def plot_decision_surface(model, X_train, y_train, X_test, y_test):
    x_min, x_max = X_train[:, 0].min() - 1, X_train[:, 0].max() + 1
    y_min, y_max = X_train[:, 1].min() - 1, X_train[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.1),
                         np.arange(y_min, y_max, 0.1))
    Z = model.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = (Z > 0.5).astype(int)

    fig, ax = plt.subplots()
    ax.contourf(xx, yy, Z.reshape(xx.shape), alpha=0.4)
    ax.scatter(X_train[:, 0], X_train[:, 1], c=y_train, s=20, edgecolor='k')
    ax.set_title('Decision Surface')
    st.pyplot(fig)

def settings_page():
    st.sidebar.title("Settings")

    # Loading datasets
    datasets = load_datasets()

    # Selecting dataset of our choice
    selected_dataset_name = st.sidebar.selectbox('Select Dataset', list(datasets.keys()))

    # Selecting ratio of training to test data
    train_test_ratio = st.sidebar.slider('Training/Test Ratio', min_value=0.1, max_value=0.9, value=0.7, step=0.1)

    # Selecting noise level
    noise_level = st.sidebar.slider('Noise Level', min_value=0.0, max_value=1.0, value=0.0, step=0.1)

    # Splitting dataset into train and test sets
    dataset = datasets[selected_dataset_name]
    X = dataset.iloc[:, :-1].values
    y = dataset.iloc[:, -1].values
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=1-train_test_ratio, random_state=42)

    # Selecting batch size
    batch_size = st.sidebar.slider('Batch Size', min_value=1, max_value=100, value=32, step=1)

    # Selecting number of epochs
    epochs = st.sidebar.slider('Epochs', min_value=1, max_value=100, value=10, step=1)

    # Selecting learning rate
    learning_rate = st.sidebar.slider('Learning Rate', min_value=0.01, max_value=0.1, value=0.01, step=0.01)

    # Selecting activation function
    activation = st.sidebar.radio('Activation Function', ['sigmoid', 'tanh', 'linear'])

    if st.sidebar.button('Submit'):
        return X_train, y_train, X_test, y_test, batch_size, epochs, learning_rate, activation
